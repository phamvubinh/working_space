#define _MSC_EXTENSIONS 
#define _INTEGRAL_MAX_BITS 64
#define _MSC_VER 1916
#define _MSC_FULL_VER 191627027
#define _MSC_BUILD 1
#define _WIN32 
#define _M_IX86 600
#define _M_IX86_FP 2
#define _CPPRTTI 
#define _DEBUG 
#define _MT 
#define _DLL 
