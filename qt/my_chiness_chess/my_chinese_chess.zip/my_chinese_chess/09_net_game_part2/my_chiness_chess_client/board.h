#ifndef BOARD_H
#define BOARD_H

#include <QFrame>
#include <QVector>
#include "piece.h"

class Board : public QFrame
{
    Q_OBJECT
public:
    explicit Board(QWidget *parent = nullptr);
    ~Board();



    /* game data */
    int _r;
    QPoint _off;
    Piece _piece[32];
    void init(bool bRedSide);

    /* draw function */
    void paintEvent(QPaintEvent*);
    void drawPlate(QPainter& p);
    void drawPalace(QPainter& p);
    void drawInitPosition(QPainter& p);
    void drawInitPosition(QPainter& p, int row, int col);
    void drawPiece(QPainter& p);
    void drawPiece(QPainter& p, int id);

    /* draw support function */
    QRect cell(int id);
    QRect cell(int row, int low);

    /* function to coodinate */
    QPoint center(int row, int col);
    QPoint center(int id);
    QPoint topleft(int row, int col);
    QPoint topleft(int id);

    /* move piece */
    void mouseReleaseEvent(QMouseEvent *);
    bool getClickRowCol(QPoint point, int & row, int & col);
    int getPieceId(int row, int col);
    void click(QPoint point);

    /* Need to be virtual function for netgame */
    virtual void click(int id, int row, int col);

    bool canSelect(int id);
    void selectPiece(int id);
    void movePiece(int id, int row, int col);
    void changePiecePos(int selectid, int row, int col);
    void changePiecePos(int _selectid, int id, int row, int col);

    /* game status */
    int _selectid;
    bool _bRedTurn;
    bool _bSide;

    /* help function */
    QString name(int id);
    bool red(int id);
    bool sameColor(int id1, int id2);
    int getStoneId(int row, int col);
    void killPiece(int id);
    bool isDead(int id);

    bool isBottomSide(int id);

    /* rule */
    bool canMove(int moveid, int killid, int row, int col);


};

#endif // BOARD_H
