#include "board.h"
#include "QPainter"
#include "QtDebug"

Board::Board(QWidget *parent):QFrame(parent)
{
    this->_r = 20;
    init(true);
}

void Board::init(bool bRedSide)
{
    for(int i = 0; i < 32; i ++)
    {
        _piece[i].init(i);
    }
}

void Board::paintEvent(QPaintEvent *)
{
    int r = height()/20;
    _r = r;
    _off = QPoint(r, r);

    QPainter p(this);
    p.setRenderHints((QPainter::Antialiasing | QPainter::TextAntialiasing));

    p.save();
    drawPlate(p);
    p.restore();

    p.save();
    drawPalace(p);
    p.restore();

    p.save();
    drawInitPosition(p);
    p.restore();

    p.save();
    drawPiece(p);
    p.restore();
}

void Board::drawPlate(QPainter &p)
{
    for(int i=0; i < 10; i++)
    {
        if(i==0 || i==9)
        {
            p.setPen(QPen(Qt::black, 3, Qt::SolidLine));
        }
        else
        {
            p.setPen(QPen(Qt::black, 1, Qt::SolidLine));
        }
        p.drawLine(center(i, 0), center(i, 8));
    }

    for(int i = 0; i < 9; ++i)
    {
        if(i==0 || i==8)
        {
            p.setPen(QPen(Qt::black, 3, Qt::SolidLine));
            p.drawLine(center(0, i), center(9, i));
        }
        else
        {
            p.setPen(QPen(Qt::black, 1, Qt::SolidLine));
            p.drawLine(center(0, i), center(4, i));
            p.drawLine(center(5, i), center(9, i));
        }

    }
}

void Board::drawPalace(QPainter &p)
{
    p.drawLine(center(0,3), center(2,5));
    p.drawLine(center(0,5), center(2,3));

    p.drawLine(center(9,3), center(7,5));
    p.drawLine(center(7,3), center(9,5));

}

void Board::drawInitPosition(QPainter &p, int row, int col)
{
    QPoint pt  = center(row, col);
    QPoint off = QPoint(_r/6, _r/6);
    int len = _r/3;

    QPoint pStart;
    QPoint pEnd;

    /* Don't draw in outside board */
    if(col != 0)
    {
        pStart = QPoint(pt.x() - off.x(), pt.y() - off.y());
        pEnd   = pStart + QPoint(-len, 0);
        p.drawLine(pStart, pEnd);
        pEnd   = pStart + QPoint(0, -len);
        p.drawLine(pStart, pEnd);

        pStart = QPoint(pt.x() - off.x(), pt.y() + off.y());
        pEnd   = pStart + QPoint(-len, 0);
        p.drawLine(pStart, pEnd);
        pEnd   = pStart + QPoint(0, len);
        p.drawLine(pStart, pEnd);
    }

    /* Don't draw in outside board */
    if (col != 8)
    {
        pStart = QPoint(pt.x() + off.x(), pt.y() - off.y());
        pEnd   = pStart + QPoint(len, 0);
        p.drawLine(pStart, pEnd);
        pEnd   = pStart + QPoint(0, -len);
        p.drawLine(pStart, pEnd);

        pStart = QPoint(pt.x() + off.x(), pt.y() + off.y());
        pEnd   = pStart + QPoint(len, 0);
        p.drawLine(pStart, pEnd);
        pEnd   = pStart + QPoint(0, len);
        p.drawLine(pStart, pEnd);
    }

}

void Board::drawInitPosition(QPainter &p)
{
    /* Draw 5 bings position */
    drawInitPosition(p, 3, 0);
    drawInitPosition(p, 3, 2);
    drawInitPosition(p, 3, 4);
    drawInitPosition(p, 3, 6);
    drawInitPosition(p, 3, 8);

    /* Draw 5 bings position */
    drawInitPosition(p, 6, 0);
    drawInitPosition(p, 6, 2);
    drawInitPosition(p, 6, 4);
    drawInitPosition(p, 6, 6);
    drawInitPosition(p, 6, 8);

    /* Draw 2 paos position */
    drawInitPosition(p, 2, 1);
    drawInitPosition(p, 2, 7);

    /* Draw 2 paos position */
    drawInitPosition(p, 7, 1);
    drawInitPosition(p, 7, 7);
}

void Board::drawPiece(QPainter& p)
{
    for(int i = 0; i < 32; i ++)
    {
        //qDebug() << "Drawing piece: " << i << endl;
        drawPiece(p, i);
    }
}

void Board::drawPiece(QPainter& p, int id)
{
    QColor color;

    //qDebug() << "Drawing piece111: " << id << endl;

    color = (id < 16) ? Qt::red : Qt::black;

    p.setPen(QPen(QBrush(color), 2));
    p.setBrush(Qt::gray);

    p.drawEllipse(cell(id));
    p.setFont(QFont("system", _r*12/10, 700));
    p.drawText(cell(id), name(id), QTextOption(Qt::AlignCenter));
}

QPoint Board::center(int id)
{
    return center(_piece[id]._row, _piece[id]._col);
}

QPoint Board::center(int row, int col)
{
    QPoint pt(_r*col*2, _r*row*2);
    /* Add offset for each position */
    return pt + _off;
}

QPoint Board::topleft(int id)
{
    return center(id) - QPoint(_r, _r);
}

QPoint Board::topleft(int row, int col)
{
    return center(row, col) - QPoint(_r, _r);
}

QRect Board::cell(int id)
{
    return QRect(topleft(id), QSize(_r*2-1, _r*2 -1));
}

QRect Board::cell(int row, int col)
{
    return QRect(topleft(row, col), QSize(_r*2-1, _r*2 -1));
}

QString Board::name(int id)
{
    return _piece[id].name();
}



Board::~Board()
{
}
