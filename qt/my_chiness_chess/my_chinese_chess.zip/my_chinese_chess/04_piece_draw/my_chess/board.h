#ifndef BOARD_H
#define BOARD_H

#include <QFrame>
#include <QVector>
#include "piece.h"

class Board : public QFrame
{
    Q_OBJECT
public:
    explicit Board(QWidget *parent = nullptr);
    ~Board();

    /* game data */
    int _r;
    QPoint _off;

    Piece _piece[32];
    void init(bool bRedSide);
    /* draw function */
    void paintEvent(QPaintEvent*);
    void drawPlate(QPainter& p);
    void drawPalace(QPainter& p);
    void drawInitPosition(QPainter& p);
    void drawInitPosition(QPainter& p, int row, int col);
    void drawPiece(QPainter& p);
    void drawPiece(QPainter& p, int id);

    /* draw support function */
    QRect cell(int id);
    QRect cell(int row, int low);

    QString name(int id);

    /* function to coodinate */
    QPoint center(int row, int col);
    QPoint center(int id);
    QPoint topleft(int row, int col);
    QPoint topleft(int id);
};

#endif // BOARD_H
