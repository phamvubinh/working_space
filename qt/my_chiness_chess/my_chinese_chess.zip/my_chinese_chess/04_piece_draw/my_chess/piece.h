#ifndef PIECE_H
#define PIECE_H

#include <QRect>
#include <QPainter>

class Piece
{
public:
    Piece();
    ~Piece();

    enum TYPE{ROOK, KNIGHT, CANNON, PAWN, KING, GUARD, BISHOP};

    int _row;
    int _col;

    void init(int id);
    TYPE _type;

    QString name();
};

#endif // PIECE_H
