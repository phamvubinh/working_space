#include "mainwindow.h"
#include "QDebug"
#include <QHBoxLayout>
#include "board.h"

MainWindow::MainWindow(int gameType, QWidget *parent) : QWidget(parent)
{
    //ui->setupUi(this);
    _gameType = gameType;

    if (_gameType == 1)
    {
        Board *game = new Board();
        QHBoxLayout* hLay = new QHBoxLayout(this);
        hLay->addWidget(game, 1);

    }
}

MainWindow::~MainWindow()
{
}
