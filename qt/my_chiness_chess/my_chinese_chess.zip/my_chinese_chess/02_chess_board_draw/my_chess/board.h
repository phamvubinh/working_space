#ifndef BOARD_H
#define BOARD_H

#include <QFrame>
#include <QVector>

class Board : public QFrame
{
    Q_OBJECT
public:
    explicit Board(QWidget *parent = nullptr);
    ~Board();

    /* draw function */
    void paintEvent(QPaintEvent *);
    void drawPlate(QPainter & p);

    /* function to coodinate */
    QPoint center(int row, int col);
    QPoint center(int id);
};

#endif // BOARD_H
