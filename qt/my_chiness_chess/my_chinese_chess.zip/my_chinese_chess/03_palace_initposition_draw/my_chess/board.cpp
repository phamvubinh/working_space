#include "board.h"
#include "QPainter"

Board::Board(QWidget *parent):QFrame(parent)
{
    //update();
}

void Board::paintEvent(QPaintEvent *)
{
    int r = height()/20;
    _r = r;
    _off = QPoint(r, r);

    QPainter p(this);
    p.setRenderHints((QPainter::Antialiasing | QPainter::TextAntialiasing));

    p.save();
    drawPlate(p);
    p.restore();

    p.save();
    drawPalace(p);
    p.restore();

    p.save();
    drawInitPosition(p);
    p.restore();
}

void Board::drawPlate(QPainter &p)
{
    for(int i=0; i < 10; i++)
    {
        if(i==0 || i==9)
        {
            p.setPen(QPen(Qt::black, 3, Qt::SolidLine));
        }
        else
        {
            p.setPen(QPen(Qt::black, 1, Qt::SolidLine));
        }
        p.drawLine(center(i, 0), center(i, 8));
    }

    for(int i = 0; i < 9; ++i)
    {
        if(i==0 || i==8)
        {
            p.setPen(QPen(Qt::black, 3, Qt::SolidLine));
            p.drawLine(center(0, i), center(9, i));
        }
        else
        {
            p.setPen(QPen(Qt::black, 1, Qt::SolidLine));
            p.drawLine(center(0, i), center(4, i));
            p.drawLine(center(5, i), center(9, i));
        }

    }
}

void Board::drawPalace(QPainter &p)
{
    p.drawLine(center(0,3), center(2,5));
    p.drawLine(center(0,5), center(2,3));

    p.drawLine(center(9,3), center(7,5));
    p.drawLine(center(7,3), center(9,5));

}

void Board::drawInitPosition(QPainter &p, int row, int col)
{
    QPoint pt  = center(row, col);
    QPoint off = QPoint(_r/6, _r/6);
    int len = _r/3;

    QPoint pStart;
    QPoint pEnd;

    /* Don't draw in outside board */
    if(col != 0)
    {
        pStart = QPoint(pt.x() - off.x(), pt.y() - off.y());
        pEnd   = pStart + QPoint(-len, 0);
        p.drawLine(pStart, pEnd);
        pEnd   = pStart + QPoint(0, -len);
        p.drawLine(pStart, pEnd);

        pStart = QPoint(pt.x() - off.x(), pt.y() + off.y());
        pEnd   = pStart + QPoint(-len, 0);
        p.drawLine(pStart, pEnd);
        pEnd   = pStart + QPoint(0, len);
        p.drawLine(pStart, pEnd);
    }

    /* Don't draw in outside board */
    if (col != 8)
    {
        pStart = QPoint(pt.x() + off.x(), pt.y() - off.y());
        pEnd   = pStart + QPoint(len, 0);
        p.drawLine(pStart, pEnd);
        pEnd   = pStart + QPoint(0, -len);
        p.drawLine(pStart, pEnd);

        pStart = QPoint(pt.x() + off.x(), pt.y() + off.y());
        pEnd   = pStart + QPoint(len, 0);
        p.drawLine(pStart, pEnd);
        pEnd   = pStart + QPoint(0, len);
        p.drawLine(pStart, pEnd);
    }

}

void Board::drawInitPosition(QPainter &p)
{
    /* Draw 5 bings position */
    drawInitPosition(p, 3, 0);
    drawInitPosition(p, 3, 2);
    drawInitPosition(p, 3, 4);
    drawInitPosition(p, 3, 6);
    drawInitPosition(p, 3, 8);

    /* Draw 5 bings position */
    drawInitPosition(p, 6, 0);
    drawInitPosition(p, 6, 2);
    drawInitPosition(p, 6, 4);
    drawInitPosition(p, 6, 6);
    drawInitPosition(p, 6, 8);

    /* Draw 2 paos position */
    drawInitPosition(p, 2, 1);
    drawInitPosition(p, 2, 7);

    /* Draw 2 paos position */
    drawInitPosition(p, 7, 1);
    drawInitPosition(p, 7, 7);
}

QPoint Board::center(int row, int col)
{
    QPoint pt(_r*col*2, _r*row*2);
    /* Add offset for each position */
    return pt + _off;
}

Board::~Board()
{
}
