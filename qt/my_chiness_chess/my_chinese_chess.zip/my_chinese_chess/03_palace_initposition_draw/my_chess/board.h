#ifndef BOARD_H
#define BOARD_H

#include <QFrame>
#include <QVector>

class Board : public QFrame
{
    Q_OBJECT
public:
    explicit Board(QWidget *parent = nullptr);
    ~Board();

    /* game data */
    int _r;
    QPoint _off;

    /* draw function */
    void paintEvent(QPaintEvent*);
    void drawPlate(QPainter& p);
    void drawPalace(QPainter& p);
    void drawInitPosition(QPainter& p);
    void drawInitPosition(QPainter& p, int row, int col);

    /* function to coodinate */
    QPoint center(int row, int col);
    QPoint center(int id);
};

#endif // BOARD_H
