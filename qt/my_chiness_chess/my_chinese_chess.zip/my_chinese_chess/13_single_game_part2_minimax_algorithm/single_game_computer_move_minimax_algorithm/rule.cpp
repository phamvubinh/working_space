#include "board.h"
#include "QDebug"
bool Board::canMove(int currentPieceID, int clickedID, int row, int col)
{
    bool canMove = true;
    if(sameColor(currentPieceID, clickedID))
    {
        return false;
    }

    switch(_piece[currentPieceID]._type)
    {
    case Piece::ROOK:
        canMove = canMoveRook(currentPieceID, clickedID, row, col);
        break;
    case Piece::KNIGHT:
        canMove = canMoveKnight(currentPieceID, clickedID, row, col);
        break;
    case Piece::CANNON:
        canMove = canMoveCannon(currentPieceID, clickedID, row, col);
        break;
    case Piece::KING:
        canMove = canMoveKing(currentPieceID, clickedID, row, col);
        break;
    case Piece::GUARD:
        canMove = canMoveGuard(currentPieceID, clickedID, row, col);
        break;
    case Piece::BISHOP:
        canMove = canMoveBishop(currentPieceID, clickedID, row, col);
        break;
    case Piece::PAWN:
        canMove = canMovePawn(currentPieceID, clickedID, row, col);
        break;
    default:
        break;
    }

    return canMove;
}


bool Board::canMoveRook(int moveid, int killid, int row, int col)
{
    int curRow = 0;
    int curCol = 0;
    int numPiece = 0;

    getRowColFromID(moveid, curRow, curCol);

    numPiece = getPieceNumAtLine(curRow, curCol, row, col);
    {
        /* Not in straight line */
        if (numPiece == -1)
        {
            return false;
        }
        /* There is at least 1 piece between line */
        else if (numPiece > 0)
        {
            return false;
        }
        else
        {
            return true;
        }
    }
}
bool Board::canMoveKnight(int moveid, int killid, int row, int col)
{
    int curRow = 0;
    int curCol = 0;

    int relation = 0;

    getRowColFromID(moveid, curRow, curCol);
    relation = getRelation(curRow, curCol, row, col);

    /* 12 or 21 is the valid value calculated follow Vertical or Horizontal value */
    if(relation != 12 && relation != 21)
    {
        return false;
    }
    else
    {
        /* Check middle path has piece or not */
        if (relation == 21)   /* Check for vertical case */
        {
            if(getPieceId((curRow+row)/2, curCol) != -1)        /* Check same col, middle row */
            {
                /* Invalid move due to the piece exist */
                return false;
            }
        }
        else   /* Check for horizontal case */
        {
            if(getPieceId(curRow, (curCol + col)/2) != -1)       /* Check same row, middle col */
            {
                /* Invalid move due to the piece exist */
                return false;
            }
        }
    }
    return true;
}
bool Board::canMoveCannon(int moveid, int killid, int row, int col)
{
    int curRow = 0;
    int curCol = 0;
    int numPiece = 0;

    getRowColFromID(moveid, curRow, curCol);

    numPiece = getPieceNumAtLine(curRow, curCol, row, col);
    /* Not in straight line */
    if (numPiece == -1)
    {
        return false;
    }
    /* There is at least 1 piece between line */
    else if ((numPiece == 1) &&  (getPieceId(row, col) != -1))
    {
        /* Has a valid piece at end point and has a middle piece */
        /* The same side condition is already checked */
        return true;
    }
    else if ((numPiece == 0) && (getPieceId(row, col) == -1))
    {
        /* Has a valid piece at end point and has a middle piece */
        /* The same side condition is already checked */
        return true;
    }

    return false;
}
bool Board::canMoveKing(int moveid, int killid, int row, int col)
{
    int curRow = 0;
    int curCol = 0;
    //int numPiece = 0;

    //qDebug() << "Check row-col " << row << "-" << col << endl;
    int relation = 0;

    getRowColFromID(moveid, curRow, curCol);

    /* If the oposite site is the opponent KING with no other piece, the King can move as a ROOK to kill */
    if(killid != -1 && _piece[killid]._type == Piece::KING)
    {
        return canMoveRook(moveid, killid, row, col);
    }

    /* Check the KING inside palace */
    relation = getRelation(curRow, curCol, row, col);
    if(relation == 10 || relation == 1)
    {
        if((col >= 3) && (col <= 5))
        {
            if(isBottomSide(moveid))
            {
                 if(row >= 7)
                 {
                     return true;
                 }
            }
            else
            {
                if(row <= 2)
                {
                    return true;
                }
            }
        }
    }
    return false;
}

bool Board::canMoveGuard(int moveid, int killid, int row, int col)
{
    int curRow = 0;
    int curCol = 0;

    int relation = 0;

    getRowColFromID(moveid, curRow, curCol);

    relation = getRelation(curRow, curCol, row, col);
    if(relation == 11)
    {
        if((col >= 3) && (col <= 5))
        {
            if(isBottomSide(moveid))
            {
                 if(row >= 7)
                 {
                     return true;
                 }
            }
            else
            {
                if(row <= 2)
                {
                    return true;
                }
            }
        }
    }
    return false;
}
bool Board::canMoveBishop(int moveid, int killid, int row, int col)
{
    int curRow = 0;
    int curCol = 0;

    int relation = 0;

    getRowColFromID(moveid, curRow, curCol);

    if(getPieceId((curRow+row)/2, (curCol+col)/2) != -1)
    {
        return false;
    }

    relation = getRelation(curRow, curCol, row, col);
    if(relation == 22)
    {
        if(isBottomSide(moveid))
        {
             if(row >= 5)
             {
                 return true;
             }
        }
        else
        {
            if(row <= 4)
            {
                return true;
            }
        }
    }
    return false;
}
bool Board::canMovePawn(int moveid, int killid, int row, int col)
{
    int curRow = 0;
    int curCol = 0;
    int relation = 0;

    getRowColFromID(moveid, curRow, curCol);

    relation = getRelation(curRow, curCol, row, col);

    if(relation != 1 && relation != 10)
    {
        return false;
    }

    if(isBottomSide(moveid))
    {
        /* Pawn can just go straigh in the house side */
        if(row < curRow)
        {
            return true;
        }

        /* Pawn can go left or right in opposite side, not in house side */
        if(row <= 4 && row == curRow)
        {
            return true;
        }
    }
    else
    {
        if(row > curRow)
        {
            return true;
        }
        if(row >= 5 && row == curRow)
        {
            return true;
        }
    }
    return false;
}

int Board::getPieceNumAtLine(int row1, int col1, int row2, int col2)
{
    int numOfPiece = 0;
    /* Check 2 position not in straight line */
    if((row1 != row2) && (col1 != col2))
    {
        return -1;
    }
    /* Check if 2 position is same */
    if((row1 == row2) && (col1 == col2))
    {
        return -1;
    }

    /* Count number of piese between straight line */
    if(row1 == row2)
    {
        int min = col1 < col2 ? col1 : col2;
        int max = col1 + col2 - min;

        for (int col = min + 1; col < max; ++col)
        {
            /* Id != -1 mean this is the piece */
            if(getPieceId(row1, col) != -1)
            {
                numOfPiece++;
            }
        }
    }
    if(col1 == col2)
    {
        int min = row1 < row2 ? row1 : row2;
        int max = row1 + row2 - min;

        /* Don't count start and end point to make sure there is 0 piece between line in other function */
        for (int row = min + 1; row < max; ++row)
        {
            if(getPieceId(row, col1) != -1)
            {
                numOfPiece++;
            }
        }
    }
    return numOfPiece;
}

int Board::getRelation(int row1, int col1, int row2, int col2)
{
    /* To check the distance follow horizontal or vertical, added weith into row value */
    return (qAbs(row2 - row1)*10 + qAbs(col2 - col1));
}

int Board::getRowColFromID(int id, int &row, int & col)
{
    if(id == -1)
    {
        return -1;
    }

    row = _piece[id]._row;
    col = _piece[id]._col;

    return 0;
}
