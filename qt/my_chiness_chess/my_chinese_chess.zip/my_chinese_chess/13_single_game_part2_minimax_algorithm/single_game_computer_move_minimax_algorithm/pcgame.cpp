#include "pcgame.h"
#include <QTimer>
#include <QDebug>
#include <QRandomGenerator>

PcGame::PcGame(QWidget *parent) : Board(parent)
{}

PcGame::~PcGame()
{}

void PcGame::click(int id, int row, int col)
{
    if(_bRedTurn)
    {
        Board::click(id, row, col);
        if(!_bRedTurn)
        {
            qDebug() << "PC turn" << endl;
            QTimer::singleShot(100, this, SLOT(pcMove()));
        }
    }
}

void PcGame::pcMove()
{
    Step* step = getBestMove();
    changePiecePos(step->_moveid, step->_killid, step->_rowTo, step->_colTo);
    delete step;
    update();
}

Step* PcGame::getBestMove()
{
#if 0
    QVector<Step*> steps;
    int pos = 0;
    getAllMove(steps);
    pos = QRandomGenerator::global()->bounded(0, steps.count() - 1);

    qDebug() << "pos is: " << pos << endl;

    qDebug() << "steps.at(pos)->_colTo " << steps.at(pos)->_colTo << endl;
    qDebug() << "steps.at(pos)->_rowTo " << steps.at(pos)->_rowTo << endl;
    return steps.at(pos);
#else
    Step* ret = nullptr;
    QVector<Step*> steps;

    getAllMove(steps);
    int maxInAllMinScore = -3000000;

    while(steps.count())
    {
        Step* step = steps.last();
        steps.removeLast();

        fakeMove(step);
        int minScore = minimax(0, false);
        unfakeMove(step);

        if(minScore > maxInAllMinScore)
        {
            if(ret)
            {
                delete ret;
            }

            ret = step;
            maxInAllMinScore = minScore;
        }
        else
        {
            delete step;
        }
    }
    return ret;
#endif
}

void PcGame::getAllMove(QVector<Step *> &steps)
{
    int min, max;
    if(this->_bRedTurn)
    {
        min = 0;
        max = 16;
    }
    else
    {
        min = 16;
        max = 32;
    }

    for(int i = min; i < max; i++)
    {
        if(this->_piece[i]._dead) continue;
        for(int row = 0; row<=9; ++row)
        {
            for(int col=0; col<=8; ++col)
            {
                int killid = this->getPieceId(row, col);
                if(sameColor(i, killid)) continue;

                if(canMove(i, killid, row, col))
                {
                    saveStep(i, killid, row, col, steps);
                }
            }
        }
    }
}

int PcGame::getScore()
{
    static int piecePoint[] = {1000, 450, 650, 200, 150000, 100, 100};
    int scoreBlack = 0;
    int scoreRed = 0;
    for(int i=0; i<16; ++i)
    {
        if(_piece[i]._dead) continue;
        scoreRed += piecePoint[_piece[i]._type];
    }
    for(int i=16; i<32; ++i)
    {
        if(_piece[i]._dead) continue;
        scoreBlack += piecePoint[_piece[i]._type];
    }
    return scoreBlack - scoreRed;
}

/*
 * QVector<Step*> steps;
    getAllPossibleMove(steps);
    int maxInAllMinScore = -300000;

    while(steps.count())
    {
        Step* step = steps.last();
        steps.removeLast();

        fakeMove(step);
        int minScore = getMinScore(level-1, maxInAllMinScore);
        unfakeMove(step);
        delete step;

        if(minScore >= curMax)
        {
            while(steps.count())
            {
                Step* step = steps.last();
                steps.removeLast();
                delete step;
            }
            return minScore;
        }
        if(minScore > maxInAllMinScore)
        {
            maxInAllMinScore = minScore;
        }


    }
    return maxInAllMinScore;
 */

int PcGame::minimax(int depth, bool isMax)
{
    int score = getScore();

    if(depth == 3)
    {
        return score;
    }

    /* If it is maximizer, try to find the maximum value */
    if(isMax)
    {
        int best = -10000;

        QVector<Step*> steps;
        getAllMove(steps);

        /* Traverse all cells */
        while(steps.count())
        {
            Step* step = steps.last();
            steps.removeLast();

            fakeMove(step);
            best = qMax(best, minimax(depth+1, !isMax));
            unfakeMove(step);
            delete step;
        }
        return best;
    }
    else
    {
        int best = 10000;

        QVector<Step*> steps;
        getAllMove(steps);

        /* Traverse all cells */
        while(steps.count())
        {
            Step* step = steps.last();
            steps.removeLast();

            fakeMove(step);
            best = qMin(best, minimax(depth+1, !isMax));
            unfakeMove(step);
            delete step;
        }
        return best;
    }

}

void PcGame::fakeMove(Step *step)
{
    killPiece(step->_killid);
    changePiecePos(step->_moveid, step->_rowTo, step->_colTo);
}

void PcGame::unfakeMove(Step *step)
{
    relivePiece(step->_killid);
    changePiecePos(step->_moveid, step->_rowFrom, step->_colFrom);
}
