#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

class MainWindow : public QWidget
{
    Q_OBJECT

public:
    explicit MainWindow(int gametype, QWidget *parent = nullptr);
    ~MainWindow();
     int _gameType;

signals:
public slots:

};

#endif // MAINWINDOW_H
