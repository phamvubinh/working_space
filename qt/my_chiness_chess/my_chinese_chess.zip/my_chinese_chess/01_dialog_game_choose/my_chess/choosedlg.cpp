#include "choosedlg.h"
#include "QVBoxLayout"
#include "QDebug"

ChooseDlg::ChooseDlg(QWidget *parent):QDialog(parent)
{
    QVBoxLayout * lay = new QVBoxLayout(this);

    lay->addWidget(_button[0] = new QPushButton("Man-machine battle"));
    lay->addWidget(_button[1] = new QPushButton("Man-man battle"));
    lay->addWidget(_button[2] = new QPushButton("Network battle server"));
    lay->addWidget(_button[3] = new QPushButton("Network battle client"));

    for (int i = 0; i < 4; i++)
    {
        connect(_button[i], SIGNAL(clicked()), this, SLOT(slotClicked()));
    }
}

void ChooseDlg::slotClicked()
{
    QObject * s = sender();

    //qDebug() << "checking sender" << s << endl;
    for(int i=0; i < 4; i++)
    {
        if(_button[i] == s)
        {
            this->_selected=i;
            break;
        }
    }
    /* Hides the modal dialog and sets the result code to Accepted. */
    accept();
}

ChooseDlg::~ChooseDlg()
{

}
