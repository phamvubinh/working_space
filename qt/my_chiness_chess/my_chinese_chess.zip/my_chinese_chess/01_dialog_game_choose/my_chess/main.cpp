#include "mainwindow.h"
#include <QApplication>
#include "choosedlg.h"

#include "QDebug"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    ChooseDlg dlg;
    if(dlg.exec() != QDialog::Accepted)
    {
        return 0;
    }
    MainWindow w(dlg._selected);
    w.show();

    return a.exec();
}
