#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(int gameType, QWidget *parent) : QWidget(parent)
{
    //ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    //delete ui;
}
