#include "pcgame.h"
#include <QTimer>
#include <QDebug>
#include <QRandomGenerator>

const int maxValue = 20000;

PcGame::PcGame(QWidget *parent) : Board(parent)
{
    _level = 4;
}

PcGame::~PcGame()
{}

void PcGame::click(int id, int row, int col)
{
    if(_bRedTurn)
    {
        Board::click(id, row, col);
        if(!_bRedTurn)
        {
            qDebug() << "PC turn" << endl;
            QTimer::singleShot(100, this, SLOT(pcMove()));
        }
    }
}

void PcGame::pcMove()
{
    Step* step = getBestMove();
    changePiecePos(step->_moveid, step->_killid, step->_rowTo, step->_colTo);
    delete step;
    update();
}

Step* PcGame::getBestMove()
{
#if 0
    QVector<Step*> steps;
    int pos = 0;
    getAllMove(steps);
    pos = QRandomGenerator::global()->bounded(0, steps.count() - 1);

    qDebug() << "pos is: " << pos << endl;

    qDebug() << "steps.at(pos)->_colTo " << steps.at(pos)->_colTo << endl;
    qDebug() << "steps.at(pos)->_rowTo " << steps.at(pos)->_rowTo << endl;
    return steps.at(pos);

    Step* ret = nullptr;
    QVector<Step*> steps;

    getAllMove(steps);
    int maxInAllMinScore = -3000000;

    while(steps.count())
    {
        Step* step = steps.last();
        steps.removeLast();

        fakeMove(step);
        int minScore = minimax(0, false, -3000000, 3000000);
        unfakeMove(step);

        if(minScore > maxInAllMinScore)
        {
            if(ret)
            {
                delete ret;
            }

            ret = step;
            maxInAllMinScore = minScore;
        }
        else
        {
            delete step;
        }
    }
    return ret;
#else
    Step * step;
    _level = 4;   //4
//    if(10<ViewModel::mD->getRecordSize()&&ViewModel::mD->getRecordSize()<=50)
//        maxDepth = 5; //4
//    if(ViewModel::mD->getRecordSize() > 50)
//        maxDepth = 5;  //5
    step = PVS(4, -maxValue, maxValue);
    return step;
#endif
}

void PcGame::getAllMove(QVector<Step *> &steps)
{
    int min, max;
    if(this->_bRedTurn)
    {
        min = 0;
        max = 16;
    }
    else
    {
        min = 16;
        max = 32;
    }

    for(int i = min; i < max; i++)
    {
        if(this->_piece[i]._dead) continue;
        for(int row = 0; row<=9; ++row)
        {
            for(int col=0; col<=8; ++col)
            {
                int killid = this->getPieceId(row, col);
                if(sameColor(i, killid)) continue;

                if(canMove(i, killid, row, col))
                {
                    saveStep(i, killid, row, col, steps);
                }
            }
        }
    }
}

int PcGame::getScore()
{
    static int piecePoint[] = {1000, 450, 750, 200, 150000, 1000, 1000};
    int scoreBlack = 0;
    int scoreRed = 0;
    for(int i=0; i<16; ++i)
    {
        if(_piece[i]._dead) continue;
        scoreRed += piecePoint[_piece[i]._type];
    }
    for(int i=16; i<32; ++i)
    {
        if(_piece[i]._dead) continue;
        scoreBlack += piecePoint[_piece[i]._type];
    }
    return scoreBlack - scoreRed;
}

int PcGame::minimax(int depth, bool isMax, int alpha, int beta)
{
    int score =  getScore();
    if(depth == 3)
    {
        return score;
    }

    /* If it is maximizer, try to find the maximum value */
    if(isMax)
    {
        int best = -30000;

        QVector<Step*> steps;
        getAllMove(steps);

        /* Traverse all cells */
        while(steps.count())
        {
            Step* step = steps.last();
            steps.removeLast();

            fakeMove(step);
            best = minimax(depth+1, !isMax, alpha, beta);
            //best    = qMax(best, val);
            //alpha   = qMax(alpha, best);

            unfakeMove(step);
            delete step;

            //if(beta <= alpha)
            //{
            //    break;
            //}
        }
        return best;
    }
    else
    {
        int best = 30000;

        QVector<Step*> steps;
        getAllMove(steps);

        /* Traverse all cells */
        while(steps.count())
        {
            Step* step = steps.last();
            steps.removeLast();

            fakeMove(step);

            best = minimax(depth+1, !isMax, alpha, beta);
            //best = qMin(val, best);
            //beta = qMin(beta, best);

            unfakeMove(step);
            delete step;

            //if(beta <= alpha)
            //{
            //    break;
            //}
        }
        return best;
    }

}

void PcGame::fakeMove(Step *step)
{
    killPiece(step->_killid);
    changePiecePos(step->_moveid, step->_rowTo, step->_colTo);
}

void PcGame::unfakeMove(Step *step)
{
    relivePiece(step->_killid);
    changePiecePos(step->_moveid, step->_rowFrom, step->_colFrom);
}

int PcGame::search(short depth, int alpha, int beta)
{
    int value = 0;

    if (depth == 0)
    {
        return getScore();
    }

    QVector<Step*> steps;
    getAllMove(steps);

    if (steps.count() == 0)
    {
        return -maxValue;
    }

    while(steps.count())
    {
        Step* step = steps.last();
        steps.removeLast();

        fakeMove(step);
        value = -search(depth-1, -beta, -alpha);
        unfakeMove(step);

        if(value >= beta)
        {
            return beta;
        }
        if(value > alpha)
        {
            alpha = value;
        }
    }
    return 0;
}

Step* PcGame::PVS(short depth, int alpha, int beta)
{
    int value = 0;
    bool flag = false;

    Step* bestMove = nullptr;

//    if(depth == 0)
//    {
//        return getScore();
//    }

    QVector<Step*> steps;
    getAllMove(steps);

//    if (steps.count() == 0)
//    {
//        return -maxValue;
//    }

    while(steps.count())
    {
        Step* step = steps.last();
        steps.removeLast();

        fakeMove(step);
        if(flag)
        {
            value = -search(depth-1, -alpha-1, -alpha);
            if(value > alpha && value < beta)
            {
                value = -search(depth-1, -beta, -alpha);
            }
        }
        else
        {
            value = -search(depth-1, -beta, -alpha);
        }

        unfakeMove(step);
        if(value >= beta)
        {
            if(beta == maxValue)
            {
                if(bestMove)
                {
                    delete bestMove;
                }
                bestMove = step;
            }
        }
        else if(value > alpha)
        {
            alpha = value;
            flag = true;
            if(depth == _level)
            {
                if(bestMove)
                {
                    delete bestMove;
                }
                bestMove = step;
            }
        }
        else
        {
            delete step;
        }
    }

    return bestMove;
}
