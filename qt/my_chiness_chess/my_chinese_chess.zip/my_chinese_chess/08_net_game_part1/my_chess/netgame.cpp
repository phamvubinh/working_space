#include "netgame.h"

NetGame::NetGame(bool server, QWidget *parent):Board(parent)
{
    _server = nullptr;
    _socket = nullptr;
    _bServer = server;

    if(_bServer)
    {
        qDebug() << "Create server";
        /* Server creates and listens to new connect signal from client */
        _server = new QTcpServer(this);
        _server->listen(QHostAddress::Any, 9899);
        connect(_server, SIGNAL(newConnection()), this, SLOT(slotNewConnection()));
    }
    else
    {
        qDebug() << "Create client";
        /* If it is client mode, create a socket to connect to server */
        _socket = new QTcpSocket(this);
        _socket->connectToHost(QHostAddress("127.0.0.1"), 9899);

        /* Connect ready signal with slotDataArrive */
        connect(_socket, SIGNAL(readyRead()), this, SLOT(slotDataArrive()));
    }
}

void NetGame::slotNewConnection()
{
    /* Check _socket is exist or not */
    if(_socket) return;

    qDebug() << "Client conneted to server";
    _socket = _server->nextPendingConnection();

    /* Connect ready signal with slotDataArrive to read data from client */
    connect(_socket, SIGNAL(readyRead()), this, SLOT(slotDataArrive()));

    /* Choose side randomly then init game */
    bool bRedSide = qrand()%2>0;
    init(bRedSide);

    /* Send init data to client */
    QByteArray buf;
    buf.append(1);
    buf.append(bRedSide?0:1);
    _socket->write(buf);
}

void NetGame::click(int id, int row, int col)
{
    /* Check turn is allowed or not */
    if(_bRedTurn != _bSide) return;

    Board::click(id, row, col);

    QByteArray buf;
    buf.append(2);
    buf.append(id);
    buf.append(row);
    buf.append(col);
    _socket->write(buf);
}

void NetGame::clickFromNetwork(QByteArray buf)
{
    Board::click(buf[1], 9-buf[2], 8-buf[3]);
}

void NetGame::initFromNetwork(QByteArray buf)
{
    bool bRedSide = buf.at(1)>0?true:false;
    init(bRedSide);
}

void NetGame::slotDataArrive()
{
    qDebug() << "Receive data through socket";
    /* Read data from socket and do coresponding action */
    QByteArray buf = _socket->readAll();

    qDebug() << "Read data: " << buf.at(0) << " " << buf.at(0) << " " << buf.at(1) << " " << buf.at(2) << endl;

    switch(buf.at(0))
    {
    case 1:
        initFromNetwork(buf);
        break;
    case 2:
        clickFromNetwork(buf);
        break;
    default:
        break;
    }
}

NetGame::~NetGame()
{}
