#ifndef NETGAME_H
#define NETGAME_H

#include "board.h"
#include <QTcpServer>
#include <QTcpSocket>

class NetGame : public Board
{
    Q_OBJECT

public:
    explicit NetGame(bool sever, QWidget *parent = nullptr);
    ~NetGame();

    bool _bServer;
    QTcpServer* _server;
    QTcpSocket* _socket;

    void click(int id, int row, int col);
    void clickFromNetwork(QByteArray buff);
    void initFromNetwork(QByteArray buff);

signals:

public slots:
    void slotNewConnection();
    void slotDataArrive();
};

#endif // NETGAME_H
