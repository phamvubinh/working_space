#include "piece.h"
#include <QDebug>

Piece::Piece()
{

}

Piece::~Piece()
{

}

QString Piece::name()
{
    switch(this->_type)
    {
    case ROOK:
        return "车";
    case KNIGHT:
        return "马";
    case CANNON:
        return "炮";
    case PAWN:
        return "兵";
    case KING:
        return "将";
    case GUARD:
        return "士";
    case BISHOP:
        return "相";
    }
    return "INV";
}

void Piece::init(int id)
{
    struct POS_STR
    {
        int row;
        int col;
        Piece::TYPE type;
    };

    struct POS_STR pos[16] =
    {
        {0, 0, Piece::ROOK},
        {0, 1, Piece::KNIGHT},
        {0, 2, Piece::BISHOP},
        {0, 3, Piece::GUARD},
        {0, 4, Piece::KING},
        {0, 5, Piece::GUARD},
        {0, 6, Piece::BISHOP},
        {0, 7, Piece::KNIGHT},
        {0, 8, Piece::ROOK},

        {2, 1, Piece::CANNON},
        {2, 7, Piece::CANNON},

        {3, 0, Piece::PAWN},
        {3, 2, Piece::PAWN},
        {3, 4, Piece::PAWN},
        {3, 6, Piece::PAWN},
        {3, 8, Piece::PAWN},
    };

    if (id < 16)
    {
        this->_col  = pos[id].col;
        this->_row  = pos[id].row;
        this->_type = pos[id].type;
    }
    else
    {
        this->_col  = 8 - pos[id-16].col;
        this->_row  = 9 - pos[id-16].row;
        this->_type = pos[id-16].type;
    }

    if (id < 16)
    {
        this->_red = true;
    }
    else
    {
        this->_red = false;
    }
    this->_dead = false;
}
