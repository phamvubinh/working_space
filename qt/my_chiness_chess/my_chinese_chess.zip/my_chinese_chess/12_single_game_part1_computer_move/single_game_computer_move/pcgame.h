#ifndef PCGAME_H
#define PCGAME_H

#include "board.h"

class PcGame : public Board
{
    Q_OBJECT
public:
    explicit PcGame(QWidget * parent = nullptr);
    ~PcGame();

    void click(int id, int row, int col);

    void getAllMove(QVector<Step *> &steps);
    Step* getBestMove();
public slots:
    void pcMove();
};

#endif // PCGAME_H
