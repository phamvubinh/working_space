#include "pcgame.h"
#include <QTimer>
#include <QDebug>
#include <QRandomGenerator>

PcGame::PcGame(QWidget *parent) : Board(parent)
{}

PcGame::~PcGame()
{}

void PcGame::click(int id, int row, int col)
{
    if(_bRedTurn)
    {
        Board::click(id, row, col);
        if(!_bRedTurn)
        {
            qDebug() << "PC turn" << endl;
            QTimer::singleShot(100, this, SLOT(pcMove()));
        }
    }
}

void PcGame::pcMove()
{
    Step* step = getBestMove();
    changePiecePos(step->_moveid, step->_killid, step->_rowTo, step->_colTo);
    delete step;
    update();
}

Step* PcGame::getBestMove()
{
    QVector<Step*> steps;
    int pos = 0;
    getAllMove(steps);
    pos = QRandomGenerator::global()->bounded(0, steps.count() - 1);

    qDebug() << "pos is: " << pos << endl;

    qDebug() << "steps.at(pos)->_colTo " << steps.at(pos)->_colTo << endl;
    qDebug() << "steps.at(pos)->_rowTo " << steps.at(pos)->_rowTo << endl;
    return steps.at(pos);
}

void PcGame::getAllMove(QVector<Step *> &steps)
{
    int min, max;
    if(this->_bRedTurn)
    {
        min = 0;
        max = 16;
    }
    else
    {
        min = 16;
        max = 32;
    }

    for(int i = min; i < max; i++)
    {
        if(this->_piece[i]._dead) continue;
        for(int row = 0; row<=9; ++row)
        {
            for(int col=0; col<=8; ++col)
            {
                int killid = this->getPieceId(row, col);
                if(sameColor(i, killid)) continue;

                if(canMove(i, killid, row, col))
                {
                    saveStep(i, killid, row, col, steps);
                }
            }
        }
    }
}
