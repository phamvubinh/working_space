#include "mainwindow.h"
#include "QDebug"
#include <QHBoxLayout>
#include "board.h"
#include "netgame.h"
#include "pcgame.h"

MainWindow::MainWindow(int gameType, QWidget *parent) : QWidget(parent)
{
    //ui->setupUi(this);
    _gameType = gameType;

    if (_gameType == 0)
    {
        PcGame *game = new PcGame();
        QHBoxLayout* hLay = new QHBoxLayout(this);
        hLay->addWidget(game, 1);
    }
    else if (_gameType == 1)
    {
        Board *game = new Board();
        QHBoxLayout* hLay = new QHBoxLayout(this);
        hLay->addWidget(game, 1);
    }
    else if(_gameType == 2)
    {
        qDebug() << "Set up Server game";
        NetGame *game = new NetGame(true);
        QHBoxLayout* hLay = new QHBoxLayout(this);
        hLay->addWidget(game, 1);
    }
    else if(_gameType == 3)
    {
        qDebug() << "Set up Client game";
        NetGame *game = new NetGame(false);
        QHBoxLayout* hLay = new QHBoxLayout(this);
        hLay->addWidget(game, 1);
    }
}

MainWindow::~MainWindow()
{
}
